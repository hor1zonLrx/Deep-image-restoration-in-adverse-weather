<div align="center">

# Awesome Adverse Weather Image Restoration

### 论文 **Deep Image Restoration in Adverse Weather: A Survey** 官方配套仓库

Zhenbo Song · Ruixin Li · Zhenyuan Zhang · Tao Wang · Jianfeng Lu · Xin Yu · Kaihao Zhang

[![Paper](https://img.shields.io/badge/Paper-Neural%20Networks-1f6feb)](https://doi.org/10.1016/j.neunet.2026.109472)
[![DOI](https://img.shields.io/badge/DOI-10.1016%2Fj.neunet.2026.109472-blue)](https://doi.org/10.1016/j.neunet.2026.109472)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

[English](README.md) | [简体中文](README_ZH.md)

</div>

<p align="center">
  <img src="assets/images/adverse_weather_examples.png" width="900" alt="不良天气退化示例">
</p>

## 🔥 News

- **2026.09** — 发布论文配套仓库，持续整理不良天气图像恢复方法、数据集、benchmark 与相关资源。
- **2026.08** — 论文被 *Neural Networks* 接收并在线发表。

## 🌟 简介

不良天气图像恢复旨在从雾、雨、雪、雨滴以及混合天气退化的输入图像中恢复清晰、可靠的视觉内容。本综述从统一视角系统梳理了 **单任务恢复** 与 **All-in-One（AiO）恢复**，覆盖网络架构、学习范式、数据集、损失函数、评价指标、实验 benchmark 与未来研究方向。

仓库结构参考了 [Awesome-Image-Restoration](https://github.com/TaoWangzj/Awesome-Image-Restoration) 的展示方式，并按照本论文的 taxonomy 重新组织。

<p align="center">
  <img src="assets/images/survey_overview.png" width="1000" alt="综述整体组织结构">
</p>

## 🔮 仓库内容

- **单任务恢复**：Dehazing / Deraining / Desnowing
- **模型演进**：CNN / GAN / Transformer / Mamba / Diffusion
- **学习范式**：Supervised / Unsupervised / Semi-Supervised
- **All-in-One 恢复**
  - One-to-One：Shared Backbone / Structured Path
  - One-to-Many：Mixture-of-Experts / Prompt Conditioning / Condition-Aware Routing / Diffusion
- **数据集**：RESIDE、RainDrop、Snow100K、All-weather、AIR40K、WeatherStream、WeatherBench 等
- **评价**：PSNR、SSIM、LPIPS、NIQE、MUSIQ、CLIP-IQA，以及下游任务指标
- **实验对比**：Dehazing、Deraining、Desnowing、Rain+Haze、Raindrop、Multi-weather
- **未来方向**：Sim2Real、Adaptive AiO、Task Utility、Efficient Deployment、Open-World Robustness

> 完整方法表、数据集表与 benchmark 数值请查看英文主 README：[`README.md`](README.md)。后续新增论文、代码链接和 benchmark 更新也优先维护英文主表。

## 📌 论文核心分类

### Single-Task Restoration

| Task | Representative model families | Representative methods |
|---|---|---|
| Dehazing | CNN / GAN / Transformer / Mamba / Diffusion | DehazeNet, FFA-Net, DeHamer, DehazeFormer, MB-TaylorFormer, MoE-Mamba, DiffDehaze |
| Deraining | CNN / GAN / Transformer / Mamba | PReNet, MSPFN, DRSformer, FADformer, FreqMamba, MS-DEMamba |
| Desnowing | CNN / GAN / Transformer / INN | DesnowNet, HDCW-Net, DDMSNet, PEUNet, SmartAssign, InvDSNet |

### All-in-One Restoration

| Paradigm | Subcategory | Representative methods |
|---|---|---|
| One-to-One | Shared Backbone | TransWeather, Restormer, Uformer, FocalNet, AIRFormer, Histoformer, ACL |
| One-to-One | Structured Path | All-in-One, MPRNet |
| One-to-Many | Mixture-of-Experts | AWRCP, MetaWeather, LDR, SLER-IR |
| One-to-Many | Prompt Conditioning | PromptIR, MPerceiver, AST, DFPIR |
| One-to-Many | Condition-Aware Routing | AirNet, OKNet, GridFormer, UHD-Processor, ILAWR, JarvisIR |
| One-to-Many | Diffusion-based | WeatherDiffusion, Diff-Plugin, DTPM, SemiDDM-weather, ResFlow, Defusion |

## 🧭 未来方向

1. 缩小 synthetic-to-real domain gap。
2. 发展更实用、可控、可自适应的 All-in-One 恢复。
3. 从 PSNR/SSIM 进一步走向下游任务效用导向的 benchmark。
4. 强化轻量化、动态推理与扩散模型加速，提升部署能力。
5. 构建面向 open-world 的可信、鲁棒、可解释恢复系统。

## 🤝 贡献

欢迎提交 Issue / Pull Request 补充：

- 新论文和新方法；
- Paper / Code 链接；
- 新数据集；
- Benchmark 更新；
- 错误修正。

具体格式见 [`CONTRIBUTING.md`](CONTRIBUTING.md)。

## 📖 Citation

```bibtex
@article{song2027deep,
  title   = {Deep Image Restoration in Adverse Weather: A Survey},
  author  = {Song, Zhenbo and Li, Ruixin and Zhang, Zhenyuan and Wang, Tao and Lu, Jianfeng and Yu, Xin and Zhang, Kaihao},
  journal = {Neural Networks},
  volume  = {205},
  pages   = {109472},
  year    = {2027},
  doi     = {10.1016/j.neunet.2026.109472}
}
```
