# Contributing

Thanks for helping maintain this adverse-weather image restoration resource.

## What you can contribute

- New papers or methods
- Official project/code links
- Dataset links and corrections
- Benchmark results
- Taxonomy corrections
- Broken-link fixes

## Suggested format for a new method

Please provide:

1. **Method**: short method name
2. **Paper**: full title
3. **Task**: dehazing / deraining / desnowing / all-in-one / other
4. **Category**: CNN / GAN / Transformer / Mamba / Diffusion / MoE / Prompt / Routing / etc.
5. **Venue + year**
6. **Paper URL**
7. **Official code URL** (if available)
8. **One-sentence summary**

## Pull requests

- Keep entries concise and consistent with the existing tables.
- Prefer official paper/project/code links.
- Do not add duplicate entries.
- If a benchmark value comes from a paper, mention the source and evaluation setting in the PR description.
