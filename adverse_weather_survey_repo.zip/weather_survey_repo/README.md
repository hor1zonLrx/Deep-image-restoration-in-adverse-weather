<div align="center">

# Awesome Adverse Weather Image Restoration

### Official repository for **Deep Image Restoration in Adverse Weather: A Survey**

Zhenbo Song · Ruixin Li · Zhenyuan Zhang · Tao Wang · Jianfeng Lu · Xin Yu · Kaihao Zhang

[![Paper](https://img.shields.io/badge/Paper-Neural%20Networks-1f6feb)](https://doi.org/10.1016/j.neunet.2026.109472)
[![DOI](https://img.shields.io/badge/DOI-10.1016%2Fj.neunet.2026.109472-blue)](https://doi.org/10.1016/j.neunet.2026.109472)
[![Awesome](https://awesome.re/badge.svg)](https://awesome.re)
[![License: CC BY 4.0](https://img.shields.io/badge/License-CC%20BY%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by/4.0/)

[English](README.md) | [简体中文](README_ZH.md)

</div>

<p align="center">
  <img src="assets/images/adverse_weather_examples.png" width="900" alt="Examples of adverse weather degradations">
</p>

## 🔥 News

- **2026.09** — We release this repository to accompany our survey and start organizing methods, datasets, benchmark results, and resources for adverse-weather image restoration.
- **2026.08** — The survey was accepted by *Neural Networks* and became available online.

## 🌟 Introduction

Adverse-weather image restoration aims to recover clean and visually reliable scenes from images degraded by haze, rain, snow, raindrops, and mixed weather. Our survey jointly reviews **single-task** and **All-in-One (AiO)** restoration from the perspectives of network architectures, learning paradigms, datasets, losses, evaluation metrics, benchmarks, and future directions.

This repository is designed as a continuously maintained companion resource for the community. It follows the organization of the survey and is inspired by the presentation style of [Awesome-Image-Restoration](https://github.com/TaoWangzj/Awesome-Image-Restoration).

### Main scope

1. **Single-task restoration** — dehazing, deraining, and desnowing.
2. **Architecture evolution** — CNN, GAN, Transformer/Mamba, and diffusion models.
3. **Learning paradigms** — supervised, unsupervised, semi-supervised, and related adaptation strategies.
4. **All-in-One restoration** — One-to-One and One-to-Many formulations, including MoE, prompts, routing, and diffusion-based methods.
5. **Evaluation** — datasets, losses, metrics, task-specific benchmarks, and cross-weather generalization.

<p align="center">
  <img src="assets/images/survey_overview.png" width="1000" alt="Survey taxonomy and organization">
</p>

## 🔮 Contents

- [1. Single-Task Restoration](#1-single-task-restoration)
  - [1.1 Image Dehazing](#11-image-dehazing)
  - [1.2 Image Deraining](#12-image-deraining)
  - [1.3 Image Desnowing](#13-image-desnowing)
- [2. All-in-One Restoration](#2-all-in-one-restoration)
  - [2.1 One-to-One](#21-one-to-one)
  - [2.2 One-to-Many](#22-one-to-many)
- [3. Datasets](#3-datasets)
- [4. Benchmark Snapshot](#4-benchmark-snapshot)
- [5. Evaluation Metrics](#5-evaluation-metrics)
- [6. Future Directions](#6-future-directions)
- [7. Contributing](#7-contributing)
- [8. Citation](#8-citation)

---

# 1. Single-Task Restoration

## 1.1 Image Dehazing

### CNN-based

| Method | Venue | Learning | Core idea / structure |
|---|---:|---|---|
| DehazeNet | TIP 2016 | SL | 4-stage CNN with Maxout + BReLU |
| MSCNN | ECCV 2016 | SL | Multi-scale residual CNN |
| AOD-Net | ICCV 2017 | SL | Residual CNN + multi-scale modeling |
| DCPDN | CVPR 2018 | SL | Dense encoder-decoder + U-Net + pyramid pooling |
| GFN | CVPR 2018 | SL | Multi-scale encoder-decoder + gated fusion |
| GridDehazeNet | ICCV 2019 | SL | Attention + multi-scale CNN |
| FAMED-Net | TIP 2019 | SL | Multi-scale CNN + dense connection |
| Deep DCP | TIP 2019 | UL | Dilated residual CNN with DCP prior |
| SSID | TIP 2019 | SSL | Encoder-decoder with attention |
| FFA-Net | AAAI 2020 | SL | Feature fusion attention |
| MSCNN-HE | IJCV 2020 | SL | Coarse-to-fine multi-scale + holistic edges |
| MSBDN | CVPR 2020 | SL | Multi-scale residual U-Net + boosted decoder |
| CCDM | CVPR 2020 | SSL | Cycle reconstruction + consistency |
| PGC | TCSVT 2020 | SL | Pyramid context guided U-Net |
| Light-DehazeNet | TIP 2021 | SL | Lightweight CNN |
| AECR-Net | CVPR 2021 | SL | Compact residual CNN + contrastive regularization |
| PSD | CVPR 2021 | SSL | Physics-compatible synthetic-to-real dehazing |
| YOLY | IJCV 2021 | UL | Layer disentanglement with J/T/A subnetworks |
| DCNet | ICME 2021 | SSL | Dual-task depth/transmission estimation |
| FSR | ACM MM 2021 | SSL | Hierarchical encoder + multi-scale supervision |
| PTTD | ECCV 2024 | SL | Prompt-based test-time adaptation |
| DCMPNet | CVPR 2024 | SL | Joint dehazing + depth estimation |
| CoA | CVPR 2025 | UL | Compression-and-adaptation for real dehazing |

### GAN-based

| Method | Venue | Learning | Core idea / structure |
|---|---:|---|---|
| Dehaze-cGAN | CVPR 2018 | SL | Encoder-decoder generator + discriminator |
| Cycle-Dehaze | CVPR 2018 | UL | CycleGAN + perceptual supervision |
| DDN | AAAI 2018 | UL | Disentangled generator + multi-scale discriminator |
| DehazeGAN | IJCAI 2018 | SL | Dense generator + PatchGAN discriminator |
| HRGAN | TCSVT 2018 | SL | Joint transmission / atmospheric light / restoration |
| EPDN | CVPR 2019 | SL | Multi-resolution generator + enhancer |
| CDNet | WACV 2019 | UL | Unpaired encoder-decoder + CycleGAN |
| Cycle-Defog2Refog | TIP 2020 | UL | Cycle-consistent fog/defog mapping |
| FD-GAN | AAAI 2020 | SL | Dense encoder-decoder + fusion discriminator |
| DW-GAN | CVPR 2021 | SL | Wavelet branch + knowledge adaptation |
| TMS-GAN | TCSVT 2021 | SL | Twofold multi-scale GAN |
| RefineDNet | TIP 2021 | WSL | Weakly-supervised refinement |
| ODCR | CVPR 2024 | UL | Orthogonal decoupling + contrastive regularization |
| UBRFC-Net | Neural Netw. 2024 | UL | Bidirectional contrastive reconstruction + FCA |
| IPC-Dehaze | CVPR 2025 | SL | VQGAN code predictor-critic |

### Transformer / Mamba / Diffusion

| Method | Category | Venue | Core idea / structure |
|---|---|---:|---|
| DeHamer | Transformer | CVPR 2022 | CNN-Transformer hybrid + physical prior embedding |
| DehazeFormer | Transformer | TIP 2023 | Hierarchical Transformer + local enhancement |
| MB-TaylorFormer | Transformer | ICCV 2023 | Taylor-series efficient attention + multi-branch design |
| MoE-Mamba | Mamba | ACM MM 2024 | Mamba backbone + intensity-aware MoE |
| DehazeXL | Transformer | CVPR 2025 | Patch tokenization + global context fusion |
| DiffLI2D | Diffusion | ECCV 2024 | Semantic latent diffusion for dehazing |
| Diff-Dehazer | Diffusion | AAAI 2025 | Stable Diffusion prior + unpaired training |
| DiffDehaze | Diffusion | CVPR 2025 | Haze generation + diffusion dehazing + accelerated sampling |

## 1.2 Image Deraining

### CNN-based

| Method | Venue | Learning | Structure / focus |
|---|---:|---|---|
| DerainNet | TIP 2017 | SL | Shallow three-layer CNN |
| DDN | CVPR 2017 | SL | Residual detail network |
| JORDER | CVPR 2017 | SL | Joint rain detection and removal |
| RESCAN | ECCV 2018 | SL | Recurrent squeeze-and-excitation aggregation |
| PReNet | CVPR 2019 | SL | Progressive recursive refinement |
| DAF-Net | CVPR 2019 | SL | Depth-attentional residual features |
| SPANet | CVPR 2019 | SL | Spatial attentive multi-stage restoration |
| UMRL | CVPR 2019 | SL | Uncertainty-guided multi-scale residual learning |
| SSIR | CVPR 2019 | SSL | Semi-supervised transfer learning |
| RaindropAttention | ICCV 2019 | SL | U-Net-like raindrop removal |
| LPNet | TNNLS 2019 | SL | Lightweight pyramid network |
| MSPFN | CVPR 2020 | SL | Multi-scale progressive fusion |
| DRD-Net | CVPR 2020 | SL | Detail-recovery context aggregation |
| RCDNet | CVPR 2020 | SL | Model-driven multi-stage network |
| Syn2Real | CVPR 2020 | SSL | Gaussian-process synthetic-to-real transfer |
| MOSS | CVPR 2021 | SSL | Memory-oriented semi-supervised learning |
| SPDNet | ICCV 2021 | SL | Structure-preserving recursive network |
| UDRDR | ICCV 2021 | SSL | Unpaired learning + rain-direction regularization |
| UDGNet | ACM MM 2021 | UL | Model-prior-driven unsupervised deraining |
| EfficientDeRain | AAAI 2021 | SL | Pixel-wise dilation filtering |
| ESDNet | IJCAI 2024 | SL | Spiking neural network for efficient deraining |
| PADUM | Neural Netw. 2025 | SL | Pixel-adaptive unfolding + state-space modeling |
| DEMore-Net | Neural Netw. 2025 | SL | Depth-guided mixture-of-rain removal |
| CSUD | CVPR 2025 | UL | Channel consistency + self-reconstruction |

### GAN-based

| Method | Venue | Learning | Focus |
|---|---:|---|---|
| DID-MDN | CVPR 2018 | SL | Density-aware multi-stream network |
| AttentGAN | CVPR 2018 | SL | Attention-guided raindrop removal GAN |
| RR-GAN | AAAI 2019 | UL | Reconstruction-guided adversarial learning |
| UD-GAN | ICIP 2019 | UL | Rain/background guidance |
| ID-CGAN | TCSVT 2019 | SL | Conditional GAN for deraining |
| HRGAN | CVPR 2019 | SL | Heavy-rain physics-guided restoration |
| DerainCycleGAN | TIP 2021 | UL | Rain-attentive CycleGAN |
| VRGNet | CVPR 2021 | SL | Rain generation-to-removal framework |
| JRGR | CVPR 2021 | SL | Joint rain generation and removal |
| DCD-GAN | CVPR 2022 | UL | Dual contrastive unpaired deraining |
| NLCL | CVPR 2022 | UL | Non-local contrastive learning |

### Transformer / Mamba

| Method | Venue | Structure / focus |
|---|---:|---|
| ELF | ACM MM 2022 | Local-global CNN/Transformer fusion |
| IDT | TPAMI 2022 | Image deraining Transformer |
| HCT-FFN | AAAI 2023 | Hybrid CNN-Transformer feature fusion |
| DRSformer | CVPR 2023 | Sparse Transformer for deraining |
| SmartAssign | CVPR 2023 | Cross-task knowledge assignment |
| SCD-Former | ICCV 2023 | Cross-layer Transformer for real rain |
| RLP | ICCV 2023 | Rain-location prior for nighttime deraining |
| NeRD-Rain | CVPR 2024 | Multi-scale implicit neural representation |
| FADformer | ECCV 2024 | Frequency-aware dual-domain Transformer |
| FreqMamba | ACM MM 2024 | Spatial/frequency/Fourier Mamba branches |
| MS-DEMamba | ACM MM 2025 | Joint deraining and low-light enhancement |

## 1.3 Image Desnowing

| Method | Category | Venue | Learning / focus |
|---|---|---:|---|
| DesnowNet | CNN | TIP 2018 | Multi-scale residual snow removal |
| JSTASR | CNN | ECCV 2020 | Joint size/transparency-aware restoration |
| HDCW-Net | CNN | ICCV 2021 | Hierarchical DTCWT + contrast channel loss |
| DDMSNet | CNN | TIP 2021 | Depth/semantic-guided multi-scale desnowing |
| Efficient Pyramid Network | CNN | ACCV 2022 | Asymmetric encoder-decoder for HD images |
| HCSD-Net | CNN | ACM MM 2023 | RGB + hue branch with multi-scale fusion |
| PEUNet | CNN / Unfolding | TCSVT 2025 | Snow-shape prior enhanced unfolding |
| SnowMaster | CNN / MLLM | CVPR 2025 | Semi-supervised mean-teacher + MLLM feedback |
| Composition GAN | GAN | IEEE Access 2019 | Joint clean background + snow-mask generation |
| DesnowGAN | GAN | TCSVT 2020 | Multi-resolution WGAN-GP restoration |
| SmartAssign | Transformer | CVPR 2023 | Smart cross-task knowledge assignment |
| InvDSNet | INN | TCSVT 2023 | Invertible separation of clean/snow layers |

---

# 2. All-in-One Restoration

The survey distinguishes two broad inference behaviors:

- **One-to-One:** all inputs follow a fixed inference path.
- **One-to-Many:** inference is explicitly adapted using degradation-related cues such as prompts, routing, gates, experts, or conditional diffusion.

## 2.1 One-to-One

### Shared Backbone

| Method | Venue | Key idea |
|---|---:|---|
| TransWeather | CVPR 2022 | Plain Transformer jointly trained across weather types |
| Restormer | CVPR 2022 | Efficient shared Transformer restoration path |
| Uformer | CVPR 2022 | U-shaped multi-scale Transformer |
| FocalNet | ICCV 2023 | Focal modulation in a unified backbone |
| AIRFormer | TCSVT 2024 | Frequency-aware Transformer for AiO weather restoration |
| Histoformer | ECCV 2024 | Histogram-guided self-attention |
| ACL | CVPR 2025 | Mamba-based linear attention for unified restoration |

### Structured Path

| Method | Venue | Key idea |
|---|---:|---|
| All-in-One | CVPR 2020 | Fixed multi-encoder architecture with NAS fusion |
| MPRNet | CVPR 2021 | Progressive multi-stage fixed restoration graph |

## 2.2 One-to-Many

### Mixture-of-Experts

| Method | Venue | Key idea |
|---|---:|---|
| Chen et al. | CVPR 2022 | Expert learning + multi-contrastive regularization |
| AWRCP | ICCV 2023 | Codebook-guided weather expert fusion |
| MetaWeather | ECCV 2024 | Meta-initialized experts for few-shot weather adaptation |
| LDR | CVPR 2024 | Language-guided expert routing |
| SLER-IR | arXiv 2026 | Spherical layer-wise expert routing |

### Prompt Conditioning

| Method | Venue | Key idea |
|---|---:|---|
| PromptIR | NeurIPS 2023 | Learnable prompts for shared restoration |
| MPerceiver | CVPR 2024 | Multimodal prompts for diffusion restoration |
| AST | CVPR 2024 | Adaptive sparse attention as conditional guidance |
| DFPIR | CVPR 2025 | Degradation-aware feature prompts |
| Wang et al. | CVPR 2025 | Feature-difference instructions + adapters |

### Condition-Aware Routing

| Method | Venue | Key idea |
|---|---:|---|
| AirNet | CVPR 2022 | Contrastive degradation representation guides restoration |
| WGWS-Net | CVPR 2023 | Weather-guided dual-branch attention |
| AiOENet | T-IV 2024 | Classification-guided encoder-decoder routing |
| OKNet | AAAI 2024 | Adaptive omni-kernel receptive-field routing |
| GridFormer | IJCV 2024 | Degradation-aware local/global path routing |
| UHD-Processor | CVPR 2025 | Degradation-aware latent + frequency routing |
| ILAWR | CVPR 2025 | Dynamic mask routing for continuous weather |
| JarvisIR | CVPR 2025 | VLM-guided system-level expert orchestration |

### Diffusion-Based Methods

| Method | Venue | Key idea |
|---|---:|---|
| WeatherDiffusion | TPAMI 2023 | Conditional DDPM with weather embeddings |
| Diff-Plugin | CVPR 2024 | High-frequency plugins for diffusion restoration |
| DTPM | CVPR 2024 | Degradation-guided texture priors |
| SemiDDM-weather | Neural Netw. 2025 | Teacher-student semi-supervised diffusion |
| ResFlow | CVPR 2025 | Reversible conditional diffusion flow |
| Defusion | CVPR 2025 | Visual-instructed degradation diffusion |

---

# 3. Datasets

## Dehazing

| Dataset | Scale | Syn/Real | Paired | Main characteristic |
|---|---:|---|:---:|---|
| FRIDA / FRIDA2 | 90 / 330 | Synthetic | ✓ | Controlled fog simulation |
| D-HAZY | 1,472 | Synthetic | ✓ | Depth-guided indoor haze |
| RESIDE | 86K+ | Syn + Real | ✓ | Large-scale standard dehazing benchmark |
| I-HAZE | 35 | Real | ✓ | Indoor real paired haze |
| O-HAZE | 45 | Real | ✓ | Outdoor real paired haze |
| Dense-HAZE | 33 | Real | ✓ | Dense real haze |
| NH-HAZE | 55 | Real | ✓ | Non-homogeneous real haze |
| Foggy Cityscapes | 20,550 | Synthetic | ✓ | Fog + semantic labels |
| HazeCOCO | 700K+ | Synthetic | ✓ | Large-scale semantic haze data |
| Haze4K | 4,000 | Synthetic | ✓ | Semi-supervised dehazing benchmark |

## Deraining

| Dataset | Scale | Syn/Real | Paired | Main characteristic |
|---|---:|---|:---:|---|
| Rain12 | 12 test | Synthetic | ✓ | Classic small benchmark |
| Rain100L / Rain100H | 1,800 / 100 each | Synthetic | ✓ | Light / heavy rain |
| Rain200L / Rain200H | 1,800 / 200 each | Synthetic | ✓ | Expanded rain benchmarks |
| RainDrop | 1,119 | Real | ✓ | Aligned adherent-raindrop pairs |
| DID-Data | 12,000 / 1,200 | Synthetic | ✓ | Rain density levels |
| Rain800 | 700 / 100 | Synthetic | ✓ | Standard paired rain-streak set |
| SPA-Data | 28,500 / 1,000 | Real | ✓ | Real-rain pairs from videos |
| MPID | 3,961 / 419 | Syn + Real | ✓ | Multi-type deraining benchmark |
| RainCityscapes | 9,432 / 1,188 | Synthetic | ✓ | Depth-aware rain + fog |
| Outdoor-Rain | 9,000 / 1,500 | Synthetic | ✓ | Heavy rain + veiling |
| Rain13K | 13,712 / 4,298 | Synthetic | ✓ | Large-scale diverse rain patterns |
| GT-RAIN | 26,124 / 2,100 | Real | ✓ | Fully real paired rain data |
| 4K-Rain13K | 12,500 / 500 | Synthetic | ✓ | Ultra-high-definition deraining |
| HQ-RAIN | 4,500 / 500 | Synthetic | ✓ | High-fidelity synthetic rain |

## Desnowing

| Dataset | Scale | Syn/Real | Paired | Main characteristic |
|---|---:|---|:---:|---|
| Snow100K | 100K+ | Syn + Real | ✓ | Multi-scale snow particles |
| SRRS | 15K+ | Syn + Real | ✓ | Snow + physical veiling |
| CSD | 10K | Synthetic | ✓ | Flakes, streaks, and veiling |
| SnowCityscapes | 2,000 / 2,000 | Synthetic | ✓ | Urban driving scenes |
| SnowKITTI2012 | 1,500 / 1,000 | Synthetic | ✓ | Geometry-sensitive driving scenes |
| RealSnow10K | 10K | Real | ✗ | Large-scale unpaired real snow |

## All-in-One / Multi-Weather

| Dataset | Scale | Syn/Real | Paired | Main characteristic |
|---|---:|---|:---:|---|
| All-weather | 18,069 train | Syn + Real | ✓ | Aggregates snow, raindrop, rain-haze |
| AIR40K | 40,000 | Syn + Real | ✓ | Unified multi-weather paired benchmark |
| HAC | 316,000 | Synthetic | ✓ | 31 hybrid combinations of five adverse factors |
| WeatherStream | 202,000 | Real | ✓ | Time-multiplexed real-weather pairs |
| WeatherBench | 42,002 | Real | ✓ | Controlled paired real rain/snow/haze |

---

# 4. Benchmark Snapshot

The following numbers are **reported results collected in the survey**. They are not necessarily reproduced under a single unified training/evaluation implementation.

| Task / Benchmark | Representative best reported result(s) |
|---|---|
| SOTS-Indoor dehazing | MB-TaylorFormer — **42.63 dB / 0.994** |
| SOTS-Outdoor dehazing | MB-TaylorFormer — **38.09 dB / 0.991** |
| Dense-HAZE | FocalNet — **17.07 dB**; OKNet — **0.640 SSIM** |
| NH-HAZE | OKNet — **20.48 dB / 0.800** |
| Rain100L | Restormer — **37.57 dB**; PromptIR — **0.979 SSIM** |
| Rain100H | FADformer — **31.48 dB / 0.916** |
| Rain800 | Restormer — **29.12 dB**; FADformer — **0.920 SSIM** |
| SPA-Data | FADformer — **49.21 dB / 0.993** |
| DID-Data | FADformer — **35.48 dB / 0.966** |
| CSD desnowing | PEUNet — **38.27 dB / 0.990** |
| SnowKITTI2012 | PEUNet — **38.53 dB / 0.988** |
| Outdoor-Rain | ResFlow — **32.82 dB / 0.936** |
| RainDrop | Defusion — **33.81 dB / 0.967** |
| All-weather → Snow100K-S | GridFormer — **37.46 dB** |
| All-weather → Snow100K-L | Histoformer — **32.16 dB / 0.926** |
| All-weather → RainDrop | MPerceiver — **33.21 dB**; DTPM/Histoformer — **0.944 SSIM** |
| All-weather → Outdoor-Rain | Histoformer — **32.08 dB / 0.939** |

---

# 5. Evaluation Metrics

### Full-reference

- **PSNR** — pixel-level fidelity.
- **SSIM / MS-SSIM** — structural similarity.
- **LPIPS** — perceptual feature-space similarity.
- **FSIM, VIF, VSI, CIEDE2000, UQI** — complementary structural, information, saliency, and color metrics.
- **FID** — distribution-level comparison.
- **mAP / IoU** — downstream detection and segmentation utility.

### No-reference

- **NIQE, BRISQUE, PIQE, SSEQ** — classical natural-scene-statistics based IQA.
- **MUSIQ, CLIP-IQA, MetaIQA, NIMA** — learned perceptual / semantic quality assessment.

---

# 6. Future Directions

- **Bridging the synthetic-to-real gap** with real paired data, semi-supervised learning, domain adaptation, and test-time adaptation.
- **Practical and adaptive All-in-One restoration** with controllable routing, prompts, expert specialization, and intelligent orchestration.
- **Task-utility-centric benchmarking** that evaluates restoration through downstream perception, not only pixel metrics.
- **Efficient deployment** through lightweight architectures, dynamic inference, compression, and accelerated diffusion sampling.
- **Trustworthy open-world restoration** with uncertainty awareness, continual adaptation, explainability, and complementary sensors.

---

# 7. Contributing

We welcome paper suggestions, corrections, new datasets, code links, and benchmark updates.

Please open an issue or pull request and follow [`CONTRIBUTING.md`](CONTRIBUTING.md). For new methods, include at least:

- method name and full paper title;
- venue and year;
- task/category;
- paper link and code link if available;
- one-sentence description of the main idea.

---

# 8. Citation

If this survey or repository is useful for your research, please cite:

```bibtex
@article{song2027deep,
  title   = {Deep Image Restoration in Adverse Weather: A Survey},
  author  = {Song, Zhenbo and Li, Ruixin and Zhang, Zhenyuan and Wang, Tao and Lu, Jianfeng and Yu, Xin and Zhang, Kaihao},
  journal = {Neural Networks},
  volume  = {205},
  pages   = {109472},
  year    = {2027},
  doi     = {10.1016/j.neunet.2026.109472}
}
```

## Acknowledgement

The repository layout is inspired by [TaoWangzj/Awesome-Image-Restoration](https://github.com/TaoWangzj/Awesome-Image-Restoration). The taxonomy, method organization, dataset summaries, benchmark values, and figures in this repository are derived from our survey.

